//
//  secondViewController.swift
//  BMI Calculator
//
//  Created by MD Sakhawat Hosen on 23/8/23.
//  Copyright © 2023 Angela Yu. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
